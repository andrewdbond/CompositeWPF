# InvalidOperationException occurs when the same view instance is added to multiple ContentControl regions
* [Description](#Description)
* [Repro Steps](#ReproSteps)
* [Offending Code](#OffendingCode)
* [Suggestion](#Suggestion)
## Description {anchor:Description}
When the same view instance is added to more than one ContentControl region, an unhandled InvalidOperationException occurs. 
## Repro Steps {anchor:ReproSteps}
# Define two ContentControl regions Region A and Region B.
# Add view1 to both the Regions A and B.
# Display Region A's view using Region A.Show(view1) method.
# Display Region B's view using Region B.Show(view1) method.
# Unhandled Exception is thrown. - "Specified element is already the logical child of another element. Disconnect it first."
## Offending Code {anchor:OffendingCode}
**File Name**: SimpleRegion.cs
**Line Nº**: 119
{{
public void Show(object view)
{
    if (!Views.Contains(view))
    {
        Add(view);
    }
    Views.MoveCurrentTo(view);
} }}
## Suggestion {anchor:Suggestion}
Before associating a view with the parent element, a conditional check can be made to find if the view is already associated with some other parent element.