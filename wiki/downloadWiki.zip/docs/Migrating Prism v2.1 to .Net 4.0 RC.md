# Migrating Prism v2.1 to .Net 4.0 RC
These are the results of the smoke tests, performed by the p&p Client Sustained Engineering team, after updating Prism v2.1 to .Net 4.0 RC version. You can download the migrated Prism bits from [here](Migrating Prism v2.1 to .Net 4.0 RC_here)(Prismv2.1Net4.0RCMIX.zip).
|**Disclaimer:** This is not a supported release. It is simply provided for demonstration purposes as to how Prism can be used with .Net 4.0 RC version.|
To run the acceptance tests, the pre-build event must be updated to (taking the RI as an example) **$(FrameworkDir)\..\v4.0.30128\msbuild.exe "$(SolutionDir)..\StockTraderRI.sln" /p:configuration=$(ConfigurationName)**.
[Image:net4Tests.png)(Image_net4Tests.png)