# Project Linker: Issue when opening a solution with solution folders from Windows Explorer
## Content
* [Problem](#Problem)
* [Cause](#Cause)
* [Fix](#Fix)
* [Workaround](#Workaround)
{anchor:Problem}
## Problem
When a solution, that contains solution folders and project links, is opened from Windows Explorer or the BAT files provided by Composite Application Library (CAL), the Project Linker does not work as expected:
* Projects are not linked
* Updates made to the source projects will not be replicated in the target projects.
* Grid inside the "Project Links" Window (Menu: Project > Edit Links) does not contain any project links.
{anchor:Cause}
## Cause
There is an issue inside the Project Linker's source code that does not detect project links when a Solution has solution folders. 
{anchor:Fix}
## Fix
Update the default implementation of the private GetProjects method of the ProjectLinkTracker class of the Project Linker’s source code to the following code:

{{
private static void GetProjects(Project project, List<Project> projects)
{
    //const string SolutionFolderGuid = "66a26720-8fb5-11d2-aa7e-00c04f688dde"; THIS LINE HAD THE WRONG CONSTANT         
    // Don't add the MiscFilesProject to the list of projects
    if (project.UniqueName == EnvDTE.Constants.vsMiscFilesProjectUniqueName) 
        return;
            
    if (project.Kind.Equals(EnvDTE.Constants.vsProjectKindSolutionItems, StringComparison.OrdinalIgnoreCase)) //USING ENVDTE CONSTANT TO CHECK IF THE ITEM IS A SOLUTION FOLDER
    {
        foreach (ProjectItem projectItem in project.ProjectItems)
        {
            if (projectItem.SubProject != null)
            {
                GetProjects(projectItem.SubProject, projects);
            }
        }
    }
    else
    {
        projects.Add(project);
    }
}
}}
This fix uses an EnvDTE constant to detect the solution folders correctly instead of the wrong constant defined inside the method (called SolutionFolderGuid).
After implement this change, you should recompile and register the new package version.
{anchor:Workaround}
## Workaround
To implement the fix, you should modify the Project Linker's source code, recompile and register it again. A workaround to avoid that is opening your solution, that contains solutions folders and project links, from Visual Studio using the "Open" or "Recent Projects" options from the "File" menu.
