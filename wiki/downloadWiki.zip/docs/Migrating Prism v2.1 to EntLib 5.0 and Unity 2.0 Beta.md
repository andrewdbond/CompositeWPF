# Migrating Prism v2.1 to EntLib 5.0 and Unity 2.0 Beta
These are the results of the smoke tests, performed by the p&p Client Sustained Engineering team, after updating Prism v2.1 to EntLib 5.0 and Unity 2.0 Beta versions. You can download the migrated Prism bits from [here](Migrating Prism v2.1 to EntLib 5.0 and Unity 2.0 Beta_here)(Prismv2.1Unity2.zip).
|**Disclaimer:** This is not a supported release. It is simply provided for demonstration purposes as to how Prism can be used with EntLib 5.0 and Unity 2.0 Beta versions.|
During the update, some of the mocks used for Unit Tests were also updated to have a single version of the MockUnityContainer across all tests.
[Image:unityTests.png)(Image_unityTests.png)