## Silverlight version of Microsoft.Practices.Composite.Tests project does not compile for some paths

**Problem:**
If the Prism v2.0 source is deployed to folder structures that include certain characters, the Composite.Silverlight.Tests.csproj does not compile.  
The characters known to cause problems are:  '%', '*', and '='.

**Cause:**
Setting up certain tests for remote module loading involves creating a xap file that needs to be processed.  The creation of this xap file is done during a PreBuild event by the Mocks\Modules\CreateXap.bat batch file.  This batch file does not properly handle certain characters in the directory path during execution.  This does affect run-time usage of Prism since unit test assemblies are not deployed, but may affect your ability to create the library assemblies.

**Workaround:**
Change the path structure to not include the particular characters causing problems or exclude this test project from the solution.