# Prism Has Moved
Prism has a [new team](http://brianlagunas.com/future-prism-library-meet-new-team/) and a [new home on GitHub](https://github.com/PrismLibrary/).

Submit issues on the [new Prism issue tracker](https://github.com/PrismLibrary/Prism/issues).
Have a feature you’d like to see included in Prism?  [Submit your PR](https://github.com/PrismLibrary/Prism/blob/master/CONTRIBUTE.md).


### Announcements

* Prism grows up - [.NET Blog](http://blogs.msdn.com/b/dotnet/archive/2015/03/19/prism-grows-up.aspx). Prism will is now open source!

* Prism for WPF now uses the Apache 2.0 license. See associated [blog post](http://blogs.msdn.com/b/blaine/archive/2014/08/22/prism-for-wpf-license-announcement.aspx).
* Prism.Mvvm and Prism.PubSubEvents now support Windows Phone 8.1 and Universal Apps. See associated [blog post](http://blogs.msdn.com/b/blaine/archive/2014/07/02/first-drop-of-prism-for-universal-apps-available-on-codeplex.aspx).
* Just released Prism Library 5.0 for WPF. For more information go  [here](http://blogs.msdn.com/b/blaine/archive/2014/04/24/prism-5-0-for-wpf-just-released.aspx).
* Prism 5.0 now supports Unity 3.5 at [http://aka.ms/prism-wpf-code](http://aka.ms/prism-wpf-code).
* Prism 4.1: can be found [here](http://msdn.microsoft.com/en-us/library/gg430869(v=pandp.40).aspx).


![](Home_http://download.codeplex.com/download?ProjectName=CompositeWPF&DownloadId=166628)

## Overview

Prism provides guidance designed to help you more easily design and build rich, flexible, and easy-to-maintain Windows Presentation Foundation (WPF) desktop applications, Silverlight Rich Internet Applications (RIAs), and Windows Phone 7 applications. Using design patterns that embody important architectural design principles, such as separation of concerns and loose coupling, Prism helps you to design and build applications using loosely coupled components that can evolve independently but that can be easily and seamlessly integrated into the overall application. These types of applications are known as composite applications.

Prism includes reference implementations, QuickStarts, reusable library code (the Prism Library), and extensive documentation. This version of Prism targets the Microsoft .NET Framework 4.0 and Silverlight 4 and includes new guidance around the Model-View-ViewModel (MVVM) pattern, navigation, and the Managed Extensibility Framework (MEF). Because Prism is built on the .NET Framework 4.0 (which includes WPF) and Silverlight 4, familiarity with these technologies is useful for evaluating and adopting Prism.

## Intended Audience

Prism is intended for software developers building WPF or Silverlight applications that typically feature multiple screens, rich user interaction and data visualization, and that embody significant presentation and business logic. These applications typically interact with a number of back-end systems and services and, using a layered architecture, may be physically deployed across multiple tiers. It is expected that the application will evolve significantly over its lifetime in response to new requirements and business opportunities. In short, these applications are "built to last" and "built for change." Applications that do not demand these characteristics may not benefit from using Prism.

It should be noted that while Prism is not difficult to learn, developers must be ready and willing to embrace patterns and practices that may be new to them. Management understanding and commitment is crucial, and the project deadline must accommodate an investment of time up front for learning these patterns and practices.

## Getting Started
* [Prism 4.1 Download](http://www.microsoft.com/download/en/details.aspx?displaylang=en&id=28950) for **WPF 4.0**, **Silverlight 5**, and **Windows Phone 7.1**
* [Prism 4 Download](http://www.microsoft.com/download/en/details.aspx?displaylang=en&id=4922) for **WPF 4.0**, **Silverlight 4**, **Windows Phone 7.0**
* [Prism Windows Runtime Download](http://aka.ms/prism-winrt-code) (formerly known as **Kona**)
* [Visual Basic Prism 4 Reference Implementations, QuickStarts, and Hands-on Labs](http://www.microsoft.com/downloads/en/details.aspx?FamilyID=bd727f0f-a52d-4503-b006-a91c375b9241)

* [Prism 4 Readme](http://msdn.microsoft.com/en-us/library/gg405471%28PandP.40%29.aspx)
* [What's new in Prism 4](http://msdn.microsoft.com/en-us/library/gg430871%28v=PandP.40%29.aspx)
* [Developer's Guide to Microsoft Prism](http://msdn.microsoft.com/en-us/library/gg406140.aspx) (versions **4.1** and **4.0** on MSDN)
* [Prism 4 Documentation](http://compositewpf.codeplex.com/releases/view/55580) in **CHM** and **PDF** formats

* [Prism Knowledge base (all versions)](http://compositewpf.codeplex.com/wikipage?title=Knowledge%20Base&referringTitle=Home)
* [Prism Known Issues (all versions)](http://www.codeplex.com/CompositeWPF/Wiki/View.aspx?title=Known%20Issues%20/%20Fixes)

## Additional Links
* [Windows Phone 7 Developer Guide](http://wp7guide.codeplex.com/) in Codeplex.
* [ManifestManagerUtility](http://compositewpf.codeplex.com/releases/view/14771) for **ClickOnce** deployment.
* [Project Linker](http://visualstudiogallery.msdn.microsoft.com/en-us/5e730577-d11c-4f2e-8e2b-cbb87f76c044) on **Visual Studio Gallery**. 
* [Model-View-ViewModel (MVVM) Training](http://visualstudiogallery.msdn.microsoft.com/3ab5f02f-0c54-453c-b437-8e8d57eb9942).
* [MVVM Overview + Prism 5.0 ViewModel Locator](http://channel9.msdn.com/Shows/Visual-Studio-Toolbox/MVVM-Best-Practices) on **Visual Studio Toolbox**

* The **patterns & practices** road-map can be found [here](http://msdn.microsoft.com/en-us/practices/bb232643). 
* The scope for **Prism for Windows Runtime** project can be found [here](http://blogs.msdn.com/b/blaine/archive/2012/12/13/prism-on-net-4-5-and-the-road-to-windows-8-apps.aspx).
 
## Previous Releases
* [Prism 2.1](http://www.microsoft.com/downloads/details.aspx?FamilyID=387c7a59-b217-4318-ad1b-cbc2ea453f40&displaylang=en) targeting **Visual Studio 2008**, **WPF** and **Silverlight 3**, named **Composite Application Guidance** on **MSDN**. 
* To learn about upgrading from previous versions of **Prism**, go [here](http://msdn.microsoft.com/en-us/library/ff921073%28v=PandP.40%29.aspx). 