# Adding same view instance from one region to another region works because WPF allows it
* [Description](#Description)
* [Scenarios](#Scenarios)
## Description {anchor:Description}
Adding the same view to another than one region will work. This is due to WPF not Composite Application Library. This casues unexpected behaviors.
## Scenarios {anchor:Scenarios}
* **Adding a view to a region twice results in an error - as per definition**
{{
object view = new object();
IRegion region = new SimpleRegion();

region.Add(view);
region.Add(view); // This will cause an exception

MessageBox.Show("shouldn't get to here"); }}
* **Adding a view that exist in one region to another will work, but adding it back to the region it was previously added to will cause an exception**: What happens is when you add the view from one region to another it will not draw in the previous region and draw in the region it was just added. But the region still has it in it's container.
{{
IRegion mainRegion = this.regionManager.GetRegion("MainRegion");
IRegion leftRegion = this.regionManager.GetRegion("LeftRegion");

LeftTestView leftView = new LeftTestView();
leftRegion.Add(leftView);
MessageBox.Show("You can see the leftView in the Left Region");

// Now add the 'leftView' to the mainRegion
mainRegion.Add(leftView);
MessageBox.Show("leftView now is showing in the MainRegion and disappear from the leftRegion");

// Now add it back to the leftRegion
leftRegion.Add(leftView); // An exception will occuring indicating the view already exist. }}