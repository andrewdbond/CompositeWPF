# Migrating Prism v2 RI from static to dynamic module loading
This article explains how to modify the **Prism-v2 Reference Implementation** so it uses **Dynamic Module Loading**. It provides good guidance on how to enable any solution that uses Static Module Loading to use Remote Module Loading, by adapting some specifics (like the module catalog).
* You can get this article in .pdf format from [here](Migrating Prism v2 RI from static to dynamic module loading_Migrate from static to dynamic module loading.pdf) 
* You can get the source code of the Prism-v2 RI using Dynamic Module Loading from [here](Migrating Prism v2 RI from static to dynamic module loading_Source Code - Prism v2 Silverlight RI.zip) 
|**Disclaimer:** The code is provided "AS IS" with no warranties, and confers no rights|

The different steps to be performed are:
* [Updating Silverlight class library projects to Silverlight application projects to generate XAP files](#Updating)
* [Setting up remote module loading](#Setting)
* [Creating a Web Application to host the RI](#Creating)
## Updating Silverlight class library projects to Silverlight application projects to generate XAP files{anchor:Updating}
To be able to load the modules dynamically a .xap file must be obtained from each of them. This requires the modification of **Silverlight Class Libraries** (which generate .dll files) to **Silverlight Applications** (which generate .xap files). Perform the following steps for each module in the Prism-v2 Reference Implementation:
* 1. Unload the module from the solution.
* 2. Open the .csproj file for edition.
![](Migrating Prism v2 RI from static to dynamic module loading_editproject.png)
* 3. Set the content of the <SilverlightApplication> node to **true** like this:
{{
<SilverlightApplication>true</SilverlightApplication>}}
* 4. Add the following node right below the <SilverlightApplication> node:
{{
<XapOutputs>true</XapOutputs>}}
* 5. Reload the module project. 
* 6. Add an XML file to the **Properties** folder of the project, named **AppManifest.xml** with this content:
{{
<Deployment xmlns="http://schemas.microsoft.com/client/2007/deployment" 
xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml">
	<Deployment.Parts>
	</Deployment.Parts>
</Deployment>}}
* 7. Set the **Build Action** property of the **AppManifest.xml** file to **‘None’**.
* 8. Open the **Properties** dialog of the project and in the **Silverlight** tab, set the following parameters:
	* In the **Xap file name** texbox, copy the module assembly name adding the ‘.xap’ suffix (i.e.: If the assembly name is **Module1** then you should put **Module1.xap**).
	* Check the **Generate Silverlight manifest file** option. 
	* Write the following in the **Manifest file template** text box: **Properties\AppManifest.xml**
* 9. Set the **Copy Local** property value to **false** in each reference of the module that is also referenced in your shell project.

## Setting up dynamic module loading {anchor:Setting}
To set up dynamic module loading a few modifications must be made to the **StockTraderRI.Silverlight** project and a **ModulesCatalog** to state each module, and how it should be loaded, has to be added to this project.
* 1.In your **Shell** project, remove references to every module in the Reference Implementation (all four of them). 
* 2.Open the **Bootstrapper.cs** file and remove the using statements to the modules’ namespaces.
* 3.Add an XML Document named **ModulesCatalog.xaml** and replace its content with the following lines inside it:
{{
<Modularity:ModuleCatalog xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
                          xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
                          xmlns:sys="clr-namespace:System;assembly=mscorlib"
                          xmlns:Modularity="clr-namespace:Microsoft.Practices.Composite.Modularity;assembly=Microsoft.Practices.Composite">
    <Modularity:ModuleInfo Ref="StockTraderRI.Modules.Market.xap" ModuleName="MarketModule" ModuleType="StockTraderRI.Modules.Market.MarketModule, StockTraderRI.Modules.Market, 
	Version=1.0.0.0" InitializationMode="WhenAvailable"/>
    <Modularity:ModuleInfo Ref="StockTraderRI.Modules.Position.xap"  ModuleName="PositionModule" ModuleType="StockTraderRI.Modules.Position.PositionModule, StockTraderRI.Modules.Position,
	 Version=1.0.0.0" InitializationMode="WhenAvailable">
        <Modularity:ModuleInfo.DependsOn>
            <sys:String>MarketModule</sys:String>
	        </Modularity:ModuleInfo.DependsOn>
    </Modularity:ModuleInfo>
	    <Modularity:ModuleInfo Ref="StockTraderRI.Modules.Watch.xap" ModuleName="WatchModule" ModuleType="StockTraderRI.Modules.Watch.WatchModule, StockTraderRI.Modules.Watch, 
	Version=1.0.0.0" InitializationMode="WhenAvailable">
        <Modularity:ModuleInfo.DependsOn>
            <sys:String>MarketModule</sys:String>
            <sys:String>PositionModule</sys:String>
        </Modularity:ModuleInfo.DependsOn>
	    </Modularity:ModuleInfo>
    <Modularity:ModuleInfo Ref="StockTraderRI.Modules.News.xap" ModuleName="NewsModule" ModuleType="StockTraderRI.Modules.News.NewsModule, StockTraderRI.Modules.News,
	 Version=1.0.0.0" />
</Modularity:ModuleCatalog>}}
* 4.Set the **Build Action** property of the **ModulesCatalog.xaml** file to **Resource**.
* 5.Change the Bootstrapper’s GetModuleCatalog method’s implementation for the following one:
{{
protected override IModuleCatalog GetModuleCatalog()
{
	return ModuleCatalog.CreateFromXaml(
	new Uri("/StockTraderRI;component/ModulesCatalog.xaml", UriKind.Relative));
} }}

## Creating a Web Application to host the Reference Implementation’s Modules {anchor:Creating}
To be able to download the different modules (XAP files) from the server, the Reference Implementation modules must be hosted in a Web Application. The following steps describe how to do this:
* 1.Create a new ASP.NET Web Application in the Silverlight folder named **StockTraderRI.Silverlight.Web**.
* 2.Open the **Properties** dialog of the new Web Application Project and go to the **Silverlight Applications** tab.
* 3.Click the Add button to add each module of the RI. Make sure that you uncheck the **“Add a test page that references the control”** checkbox.
* 4.After adding the RI’s modules, add the Shell project (StockTraderRI.Silverlight), but this time leave the “Add a test page that references the control” checkbox option checked.
![](Migrating Prism v2 RI from static to dynamic module loading_Add Silverlight Application.png)
* 5.Close the properties dialog.
* 6.Set as the start page the page generated to test the Shell project. The name of the page should be something similar to **StockTraderRI.SilverlightTestPage.aspx**.
* 7.Set the new **Web Application** as the **StartUp Project**.
* 8.Rebuild the solution.
* 9.Run the solution.

Having performed these steps, the Prism-v2 Reference Implementation for Silverlight will be loading its modules dynamically.