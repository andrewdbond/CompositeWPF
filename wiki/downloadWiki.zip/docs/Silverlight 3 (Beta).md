## Silverlight 3 & SL3 Beta
* [Why Silverlight 3 Navigation cannot be fully leveraged when loading modules remotely with Prism 2](http://blogs.southworks.net/dschenkelman/2009/11/05/why-silverlight-3-navigation-cannot-be-fully-leveraged-when-loading-modules-remotely-with-prism-2/)
	* **Version:** 2.0
	* **Description:** Article that explains why Silverlight 3 Navigation cannot be fully leveraged when loading modules remotely with Prism 2.
* [Composite Application Guidance for WPF & Silverlight (Prism-v2) Reference Implementation using Silverlight 3 Validation](http://blogs.southworks.net/dschenkelman/2009/07/15/composite-application-guidance-for-wpf-silverlight-prism-v2-reference-implementation-using-silverlight-3-validation/)
	* **Version:** 2.0
	* **Description:** This blog post details how to migrate the Prism-v2 RI to Silverlight 3 and use Silverlight 3 Validation.
* [Composite Application Guidance (Prism-v2) sample application using Silverlight 3 Child Window](http://blogs.southworks.net/dschenkelman/2009/06/30/composite-application-guidance-prism-v2-sample-application-using-silverlight-3-child-window/)
	* **Version:** 2.0
	* **Description:** This blog post provides a sample to use the Silverlight 3 Child Window in a Prism-v2 application.
* [Prism-v2 Reference Implementation migrated to Silverlight 3 with Out-Of-Browser Capabilities](http://blogs.southworks.net/dschenkelman/2009/07/14/prism-v2-reference-implementation-migrated-to-silverlight-3-official-release-with-out-of-browser-capabilities/)
	* **Version:** 2.0
	* **Description:** This blog post details how to migrate the Prism-v2 RI to Silverlight 3 and add out-of-browser capabilities to it.
* [Commands with Attached Behavior for Silverlight 3 DataForm](http://blogs.southworks.net/dschenkelman/2009/04/18/commands-with-attached-behavior-for-silverlight-3-dataform/)
	* **Version:** 2.0
	* **Description:** This blog post explains how to create commands with attached behaviors for the Silverlight 3 DataForm control.
* [How To: Integrate a Prism v2 application with the Silverlight 3 Navigation Framework](http://blogs.southworks.net/mconverti/2009/04/12/how-to-integrate-a-prism-v2-application-with-the-silverlight-3-navigation-framework/)
	* **Version:** 2.0
	* **Description:** This blog post details how to use Silverlight 3 Navigation Framework and Prism-v2.
* [Prism 2 & Silverlight 3 Beta Navigation](http://compositewpf.codeplex.com/Thread/View.aspx?ThreadId=51053)
	* **Version:** 2.0
	* **Description:** This thread discusses using Silverlight 3.0 Beta navigation, with Prism-v2 Remote Module Loading feature.