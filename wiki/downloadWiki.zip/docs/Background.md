Prism provides the following benefits:
* Provides support for WPF and Silverlight
* Dynamically composes user interface components
* Application modules can be developed, tested and deployed by separate teams
* Allows incremental adoption
* Provides an integrated user experience 
* Helps you build applications in WPF and Silverlight that have a single code base

Even single-person projects experience benefits in creating more testable and maintainable applications using this modular approach.

"Prism" is not a port of previous smart client offerings, instead it is a new deliverable that is optimized for WPF and Silverlight. It aims to deliver a simplified approach that is more easily adoptable. 

Read what people are saying about "Prism" below.

Team perspective
[http://blogs.msdn.com/blaine/archive/2009/02/18/prism-2-0-is-live.aspx](http://blogs.msdn.com/blaine/archive/2009/02/18/prism-2-0-is-live.aspx)
[http://blogs.msdn.com/francischeung/archive/2008/01/28/composite-wpf-guidance.aspx](http://blogs.msdn.com/francischeung/archive/2008/01/28/composite-wpf-guidance.aspx)
[http://blogs.msdn.com/gblock/archive/2007/10/26/wpf-composite-client-guidance-it-s-coming.aspx](http://blogs.msdn.com/gblock/archive/2007/10/26/wpf-composite-client-guidance-it-s-coming.aspx)
[http://www.softinsight.com/bnoyes/2008/01/07/DifferentiatedUserExperienceUX.aspx](http://www.softinsight.com/bnoyes/2008/01/07/DifferentiatedUserExperienceUX.aspx)


Customer perspective
[http://ctrl-shift-b.blogspot.com/2008/01/early-glimpse-of-future-composite-smart.html](http://ctrl-shift-b.blogspot.com/2008/01/early-glimpse-of-future-composite-smart.html)
[http://neverindoubtnet.blogspot.com/2008/01/prism-camp-reflections-on-composite-wpf.html](http://neverindoubtnet.blogspot.com/2008/01/prism-camp-reflections-on-composite-wpf.html)

**Source**

The source in the spikes folder are for illustrative purposes only. These will not be part of the final deliverable. The spikes have a dependency on Castle Windsor ("Prism" will not depend on it). Castle Windsor can be downloaded from [http://www.castleproject.org/castle/download.html](http://www.castleproject.org/castle/download.html)
