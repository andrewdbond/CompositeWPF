{rss:url=http://blogs.msdn.com/blaine/rss_tag_Prism.xml,max=4,titlesOnly=true}
{rss:url=http://blogs.msdn.com/dphill/rss_tag_Prism.xml,max=4,titlesOnly=true}
{rss:url=http://blogs.msdn.com/erwinvandervalk/rss.xml,max=4,titlesOnly=true}
{rss:url=http://blogs.msdn.com/bobbrum/rss.xml,max=4,titlesOnly=true}
{rss:url=http://staff.southworks.net/blogs/ejadib/rss.aspx?Tags=Prism&AndTags=1,max=4,titlesOnly=true}
{rss:url=http://feeds.southworks.net/sw-jdominguez?Tags=Prism&AndTags=1,max=4,titlesOnly=true}
