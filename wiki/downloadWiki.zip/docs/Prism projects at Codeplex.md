## Prism projects at Codeplex

This list shows some of the projects on codeplex that are using Prism. The values for **Downloads** and **Visits** are updated to 5/21/2010.

## [CSLA.NET Contrib](http://cslacontrib.codeplex.com)
![CSLA.NET Contrib](Prism projects at Codeplex_http://download.codeplex.com/download?ProjectName=CSLAcontrib&DownloadId=91317&Build=16586)

This is a collection of contributions to Rockford Lhotka's CSLA .NET framework, which may include tools, add-ons, best practices and customizations that make it easier to use CSLA .NET.

* Downloads: 22816
* Visits: 60760
----

## [Multi-Touch Vista](http://multitouchvista.codeplex.com)
![Multi-Touch Vista](Prism projects at Codeplex_http://download.codeplex.com/download?ProjectName=MultiTouchVista&DownloadId=34826&Build=16586)

Multi-Touch Vista is a user input management layer that handles input from various devices (touchlib, multiple mice, TUIO etc.) and normalises it against the scale and rotation of the target window. Now with multitouch driver for Windows 7.

* Downloads: 21421
* Visits: 76124
----

## [Scrum Sprint Monitor](http://scrumsprintmonitor.codeplex.com)
![Scrum Sprint Monitor](Prism projects at Codeplex_http://download.codeplex.com/download?ProjectName=scrumsprintmonitor&DownloadId=67248&Build=16586)

Scrum Sprint Monitor provides the Agile team with hands-off, always up-to-date status of the current Sprint, both at the individual and team level.

* Downloads: 12495
* Visits: 16568
----

## [MyBusiness.NET](http://mybusinessnet.codeplex.com)

MyBusiness.NET is a .NET OpenSource ERP - System developed in C# using WPF, Entity Framework, MS-SQL-Server and MVVM.

* Downloads: 7333
* Visits: 15005
----

## [Calcium](http://calcium.codeplex.com)
![Calcium](Prism projects at Codeplex_http://download.codeplex.com/download?ProjectName=Calcium&DownloadId=68571&Build=16586)

Calcium is a WPF composite application toolset that leverages the Composite Application Library. It consists of a client application and server based WCF services, which allow interaction and communication between clients.

* Downloads: 6322
* Visits: 14146
----

## [Data Access Guidance](http://dataguidance.codeplex.com)
![Data Access Guidance](Prism projects at Codeplex_http://download.codeplex.com/download?ProjectName=dataguidance&DownloadId=82981&Build=16586)

This Data Access Guidance project illustrates how to implement the Repository, Unit of Work, Specification, State and other patterns using ADO.NET Entity Framework 4.0, the ASP.NET MVC framework, Unity, Prism, and the WCF REST Starter Kit. 

* Downloads: 2687
* Visits: 10388
----

## [Photoviewer](http://photoviewer.codeplex.com)

This project was created to provide an application to manage a personal photo collection. Aside from being a personal photo management solution this project is also here to learn more about designing domain driven applications using Composite WPF.

* Downloads: 2504
* Visits: 3980
----

## [Composite Extensions/Test Suite Reference Implementation](http://compositeextensions.codeplex.com)

This project provides a new reference implementation for the Composite WPF libraries.

* Downloads: 1876
* Visits: 16553
----

## [Composite WPF Shell](http://compositewpfshell.codeplex.com)

The purpose of this project is to develop a standard WPF application shell using the Composite Application Guidance for WPF. This project will develop standards, patterns, and best practices for building composite applications using WPF.

* Downloads: 1345
* Visits: 3052
----

## [NetAdvantage for CAL](http://ncal.codeplex.com)

The NetAdvantage for Composite Application Library (NCAL) from Infragistics enables NetAdvantage for WPF to be used in a composite WPF application. NCAL is a lightweight layer of code that provides region adapters for key Infragistics WPF components.

* Downloads: 1256
* Visits: 9157
----

## [FRC1103 - FRC Dashboard Viewer](FRC1103 - FRC Dashboard Viewer)

This dashboard viewer and library is intended to be an alternative to the LabView dashboard viewer provided by FIRST and NI.

* Downloads: 1239
* Visits: 1349
----

## [Krystal POS](http://krystal.codeplex.com/)

Point of sales application for Microsoft Dynamics AX (Axapta)

* Downloads: 1113
* Visits: 1643
----

## [Simon](http://simon.codeplex.com)

![Simon](Prism projects at Codeplex_http://download.codeplex.com/download?ProjectName=Simon&DownloadId=69276&Build=16586)

Composite Surface/WPF/Silverlight 3/Silverlight 3 OOB project for fun and for demo-ing going from Silverlight to WPF and the use or resources in both kinds of projects and then again going from WPF to Surface allowing users to show the differences between all 3.5 environments.

* Downloads: 934
* Visits: 4272
----

## [Prism Tutorial](http://prismtutorial.codeplex.com)
![Prism Tutorial](Prism projects at Codeplex_http://download.codeplex.com/download?ProjectName=prismtutorial&DownloadId=90139&Build=16586)

Prism tutorial is a sample application that uses the Microsoft Adventure Works Light database to demonstrate how to build an application that uses: Entity Framework, WCF, WPF, Prism, EntLib for the Application Blocks.

* Downloads: 933
* Visits: 7077
----

## [Silverlight for Commercial - Large Scale Domains with RIA, Prism, Unity and MEF](http://pushbomb.codeplex.com)
![Silverlight for Commercial - Large Scale Domains with RIA, Prism, Unity and MEF](Prism projects at Codeplex_http://download.codeplex.com/download?ProjectName=pushbomb&DownloadId=79816&Build=16586)

The convergence and emergence of a set of critical enablers for the the commercial developer are here. Buzzwords to many become mandates to success and even existence when your revenue is your software. Doing it is still too hard and this is why we offer our emerging mashup here.

* Downloads: 824
* Visits: 2834
----

## [Composure](http://composure.codeplex.com)

Composure will attempt to consolidate various interesting CodePlex frameworks into a comprehensive build environment for implementing non-trivial spikes and prototypes related to composite application and system development.

* Downloads: 643
* Visits: 4279
----

## [Matchingo](http://matchingo.codeplex.com)

Matchingo is an implementation of a card matching game, built using C# .Net 3.5 SP1, Silverlight, Composite Silverlight (Prism), Silverlight Unit Test Framework, and using development techniques including composite UI, the Model-View-ViewModel (MVVM) pattern, dependency injection, unit tests, event aggregation, LINQ, llamda expressions, and more.

* Downloads: 564
* Visits: 1445
----

## [Silverlight MVVM Toolkit](http://silverlightmvvm.codeplex.com)
![Silverlight MVVM Toolkit](Prism projects at Codeplex_http://michaelsync.net/wp-content/uploads/2009/06/Silverlight-MVVM-Toolkit.jpg)

The Silverlight Model-View-ViewModel Toolkit is created for those who are using Model-View-ViewModel design pattern for building Silverlight Business Application.

* Downloads: 433
* Visits: 3750
----

## [PRISM Dashboard RI](http://roygbiv.codeplex.com)

This is a simple reference implementation using PRISM to exemplify some of the core concepts and best practices for developing composite WPF and Silverlight applications.

* Downloads: 432
* Visits: 617
----

## [MVVM Reference Application](http://mvvmref.codeplex.com)

Community created reference application for M-V-VM frameworks to use for demonstration purposes, similar in concept to Pet Shop for web frameworks.

* Downloads: 333
* Visits: 5365
----

## [GWN-EHR](http://ehr.codeplex.com)
![GWN-EHR](Prism projects at Codeplex_http://download.codeplex.com/download?ProjectName=EHR&DownloadId=103911&Build=16586)

GWN-EHR: Open Source Electronic Health Record (EHR) Management System. Our vision statement is to create a Complete EHR in compliance with "Meaningful Use" criteria using the latest Microsoft Technologies such as Azure, MEF, PRISM, Unity, HealthVault SDK, etc. 

* Downloads: 293
* Visits: 804
----

## [Nquisite](http://nquisite.codeplex.com)

NQuisite aims to become the greatest Web Services exploring and testing application ever, with main focus set on WCF services.

* Downloads: 237
* Visits: 344
----

## [WCF RIA Services LoB Application](http://telecosystems.codeplex.com)

WCF RIA Services LoB application is a sample application that shows how to create Modular Silverlight applications with PRISM (Composite App Library) and WCF RIA Services.

* Downloads: 182
* Visits: 727
----

## [Sofia](http://sofia.codeplex.com)

A composite WPF application made with Acropolis. Targets small business world.

* Downloads: 172
* Visits: 623
----

## [RoboDojo](http://robodojo.codeplex.com)

Implemented in C#, RoboDojo is a simple battle bot game in which developers implement their own bots to do battle with each other.

* Downloads: 160
* Visits: 379
----

## [SimpleQualityControl](http://equal.codeplex.com)

A Quality control project. A simple extensible realization of ISO 9001.

* Downloads: 110
* Visits: 147
----

## [Convert.net](http://convertdotnet.codeplex.com)

Convert.net is a tutorial-based project to provide a free, professional and robust app to easily convert between image formats. It is for anyone wishing to convert files, either singly or in bulk.

* Downloads: 93
* Visits: 216
----

## [Refract](http://refract.codeplex.com)

This library provides core functionality to facilitate the MVVM pattern in Silverlight using Prism. It also provides support for deep linking navigation using Prisms modularity namespace.

* Downloads: 60
* Visits: 294
----

## [DigitalFrame](http://digitalframe.codeplex.com)

A WPF Application written using the Prism framework which can be used for a Laptop -> Digital Picture Frame conversion project.

* Downloads: 53
* Visits: 254
----

## [World Index](http://worldindex.codeplex.com)

The World Index project is a Silverlight project that is built to expose UN Millenium development goals using their public available data as datasource.

* Downloads: 40
* Visits: 396
----

## [Silverlight Application Framework](http://slap.codeplex.com)

Silverlight Application framework using Silverlight,MEF,Sync,Sockets,duplex,charting,rest and many more.

* Downloads: 34
* Visits: 269
----

## [.Net 4.0 WPF Twitter Client](http://wpftwitterclient.codeplex.com)

A .Net 4.0 Twitter client application built in WPF using Prism.

* Downloads: 26
* Visits: 169
----

## [Visual Stock](http://visualstock.codeplex.com)

![Visual Stock](Prism projects at Codeplex_http://download.codeplex.com/download?ProjectName=visualstock&DownloadId=111669&Build=16586)

Visual Stock is a stock data retreive, anlysis and visualisation application build on Microsoft Composite Application Library.

* Downloads: 25
* Visits: 196
----

## [uTorrent-Net-Client](http://utorrentnetclient.codeplex.com)

A network client for uTorrent over the uTorrent-WebAPI. 

* Downloads: 24
* Visits: 180
----

## [Rapid Dictionary](http://rapiddict.codeplex.com)

Rapid Dictionary is a Translation Dictionary initialized by language learning network http://WordSteps.com.

* Downloads: 23
* Visits: 118
----

## [SmartFront](http://smartfront.codeplex.com)

SmartFront is a group of utilities and framework pieces which allow to quickly building Smart Client application in WPF and in Silverlight.

* Downloads: 20
* Visits: 143
----

## [NColony](http://ncolony.codeplex.com)

NColony helps aggregate, filter, and prioritize various sources of information. Initially, this project will support RSS feeds. But, future versions will support any source of information updates (i.e. Twitter, Facebook, Google Wave, E-mail, etc.)

* Downloads: 10
* Visits: 193
----

## [Composite WPF Extensions](http://calex.codeplex.com)

Extensions to Composite Client Application Library for WPF.

* Downloads: 5
* Visits: 50
----

## [POCO Bridge](http://pocobridge.codeplex.com)

This project aims to provide a solution for bridging Silverlight and Pure .NET code.

* Downloads: 1
* Visits: 7
----

## [Peacock](http://peacock.codeplex.com)

A browser like tabbed application

* Downloads: 0
* Visits: 5
----

## [HappyNet](http://happynet.codeplex.com)
![HappyNet](Prism projects at Codeplex_http://download.codeplex.com/download?ProjectName=happynet&DownloadId=122827&Build=16586)

HappyNet is a project using best practices to build an e-commerce web site. It is a full Silverlight application based on a solid architecture (PRISM + MVVM) and the AventureWorks database. It tries to answer some frequent needs and questions from the web.

* Downloads: 0
* Visits: 0
----