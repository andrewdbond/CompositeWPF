### Prism Documentation Pages

* [Developers Guide to Microsoft Prism 5 on MSDN](http://aka.ms/prism-wpf-doc)

* [Prism v4 Documentation Page](http://compositewpf.codeplex.com/releases/view/55580)

* [Developers Guide to Microsoft Prism 4 on MSDN](http://msdn.microsoft.com/en-us/library/gg406140.aspx) 

* [Prism v1 and v2 Documentation Page](http://compositewpf.codeplex.com/releases/view/14982)