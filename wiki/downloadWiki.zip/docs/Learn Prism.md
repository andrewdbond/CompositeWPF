## Overview
* [Elegant Code Cast of Prism v2](http://elegantcode.com/2009/04/22/code-cast-26-prism-20/)
* [Sparkling Client Cast of 10 Things to Know About Prism for Silverlight](http://www.sparklingclient.com/prism-silverlight/)
* [Prism v2 - Composite Application Guidance for WPF and Silverlight](http://channel9.msdn.com/shows/Continuum/Prismv2/)
* [What is Prism v2](http://channel9.msdn.com/posts/akMSFT/What-is-Prism-v2/)
* [Watch the InfoQ interview on Prism 1.0](http://www.infoq.com/interviews/Prism-Glenn-Block)

## How do I
* Build a modular Silverlight application (four part series)
	* [Creating a solution and adding a module (10 minutes)](http://channel9.msdn.com/posts/akMSFT/Creating-a-modular-application-using-Prism-V2-Part-1-of-4--Creating-a-shell-and-modules/)
	* [Composing the views (10 minutes)](http://channel9.msdn.com/posts/akMSFT/Creating-a-modular-application-using-Prism-V2-Screencast-24--Visual-Composition/)
	* [Implementing a view and using services (22 minutes)](http://channel9.msdn.com/posts/akMSFT/Creating-a-modular-application-using-Prism-V2-Screencast-34--Implementing-views-and-services/)
	* [Communicating between views (24 minutes)](http://channel9.msdn.com/posts/akMSFT/Creating-a-modular-application-using-Prism-v2-Screencast-44--Decoupled-Communication/)
	* Download [the source](Learn Prism_Channel9NewsAggregatorSource.zip) for this series.