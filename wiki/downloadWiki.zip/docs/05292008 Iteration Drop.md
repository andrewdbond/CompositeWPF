# Summary of what's new in this drop
# [Bootstrapper: Extracted common functionality into a base class](#Bootstrapper)
# [Documentation](#Documentation)
# [Integrated Event Aggregation in RI](#EventAggregation)
# [New Commanding QuickStart](#QuickStart)
# [New StaticModuleEnumerator implementation](#Implementation) 
# Several Bugs Fixed
### Bootstrapper: Extracted common functionality into a base class {anchor:Bootstrapper} 
A new base class named **UnityPrismBootstrapper** was introduced. This class provides common code for a **Bootstrapper** that uses the **Unity** container. The main methods are the following:
* **Run**. This method starts the Bootstrapper process.
* **Configure Container.**This method configures the Unity container. It may be overwritten in a derived class to register application-specific type mappings. It can configure the container with the default configuration depending on a flag that you pass to the **Bootstrapper.Run** method. It registers type mappings in case you didn't add them before.
* **ConfigureRegionAdapterMappings**. This method configures the default region adapter mappings to use in the application. This method may be overwritten in a derived class to add specific mappings required by the application.
* **InitializeModules**. This method initializes the modules. It may be overwritten in a derived class to use custom module loading and to avoid using an **IModuleLoaderService** and **IModuleEnumerator**.
* **CreateContainer**. This method creates the **IUnityContainer** that will be used as the default container.
* **GetModuleEnumerator**. This method returns the module enumerator that will be used to initialize the modules. When using the default initialization behavior, this method must be overwritten by a derived class.
* **ShowShell**. In this template method you show the Shell window and return it. You return this object because it will be injected with the default region manager of the application to be able to add regions using the **RegionManager.RegionNameProperty** attached property from XAML.
All the solutions included in the drop have been updated to use this new implementation.
### Documentation {anchor:Documentation}
* Added RI Background
* Added What is going on in the RI?
* Added Technical Concepts
* Added Design Concepts
* Added several How-To docs
### Integrated the Event Aggregation service in the Stock Trader Reference Implementation {anchor:EventAggregation}
![](05292008 Iteration Drop_stocktrader.png)
The Event Aggregation service was integrated in the Stock Trader Reference Implementation (RI) to establish loosely coupled communications between components. The Event Aggregation service is used in the RI to update stock’s market price and to show related news articles when a stock is selected.
The **MarketPricesUpdatedEvent** event is raised when the stock’s market price is automatically updated after a time interval. This event is used by the modules StockTraderRI.Modules.Market and StockTraderRI.Modules.Position to communicate in a loosely coupled way. The following code shows the event class signature; the class extends the PrismEvent<TPayload> class specifying a dictionary as the payload type.

{{
public class MarketPlacesUpdatedEvent : PrismEvent <IDictionary<string, decimal>>
{

} }}
#### Event Subscription
The following code shows a line of the **PositionSummaryPresenter** class’ constructor. In this line an event handler for the **MarketPricesUpdatedEvent** event is subscribed using the Event Aggregator service.

{{
eventAggregator.Get<MarketPricesUpdatedEvent>().Subscribe(MarketPricesUpdated, ThreadOption.UIThread);
}}
#### Event Publishing
When stock’s market prices are updated, the event **MarketPricesUpdatedEvent** is published by the **MarketFeedService** class. The following code shows how this happens.

{{
private void OnMarketPricesUpdated()
{
    var clonedPriceList = new Dictionary<string, decimal>(_priceList);

    EventAggregator.Get<MarketPricesUpdatedEvent>().Publish(clonedPriceList);
}
}}
### New commanding QuickStart {anchor:QuickStart}
The Commanding QuickStart demonstrates how to build a Windows Presentation Foundation (WPF) user interface that uses commands to handle UI actions in a decoupled way. The Commanding QuickStart is based on a fictitious product ordering system where the user can place customer orders.
This QuickStart contains the following commands:
* SaveOrder: this command is fired when the user submits a single order.
* SaveAllOrders: this command is fired when the user clicks on the toolbar button to submit all orders.
These commands get enabled or disabled depending on validation rules on the order form.
### New StaticModuleEnumerator Implementation {anchor:Implementation}
The class **StaticModuleEnumerator** class was introduced in Prism. This module enumerator facilitates the task of statically adding modules to your application. The following code, extracted from the Stock Trader reference implementation, shows an example usage of this module enumerator:

{{
protected override IModuleEnumerator GetModuleEnumerator()
{
    return new StaticModuleEnumerator()
        .AddModule(typeof(NewsModule))
        .AddModule(typeof(MarketModule))
        .AddModule(typeof(WatchModule), "MarketModule")
        .AddModule(typeof(PositionModule), "MarketModule", "NewsModule");
}
}}