## Composite Application Guidance for WPF

* [Voodoo?](http://www.codeplex.com/CompositeWPF/Thread/View.aspx?ThreadId=24804)
	* **Version:** all
	* **Description:** Question on RegionManagers.

* [IModuleEnumerator guidance](http://www.codeplex.com/CompositeWPF/Thread/View.aspx?ThreadId=26886)
	* **Version:** all
	* **Description:** Information on module enumration.

* [DirectoryLookupModuleEnumerator Child AppDomain](http://www.codeplex.com/CompositeWPF/Thread/View.aspx?ThreadId=27047)
	* **Version:** all
	* **Description:** Information on why a child AppDomain is created in DirectoryLookupModuleEnumerator.EnsureModulesDiscovered.