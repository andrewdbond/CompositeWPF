Composite Application Guidance for WPF and Silverlight - Readme file 
Welcome to the first drop of the Composite Application Guidance for WPF and Silverlight. This file contains information that can be useful in using the guidance.

============================
What's included in this drop
============================
• The Project Linker tool installer
• The Multi-Targeting QuickStart
• The Multi-Targeting Visual Studio templates

============
Requirements
============
•Microsoft Visual Studio 2008 SP1
•Microsoft .NET Framework 3.5 (the .NET Framework 3.5 includes WPF)
•Microsoft Silverlight 2 Beta 2 
•Silverlight Unit Testing Framework (For download and installation instructions see http://code.msdn.microsoft.com/silverlightut)
•Microsoft Visual Studio 2008 Software Development Kit (SDK) 1.0 for running or compiling Project Linker

============
Installation
============
To install the QuickStart unzip the Source.zip file into any folder of your choice.
NOTE: In order to compile from source, you will need to add the Silverlight Unit Testing Framework files to the LIB\Silverlight\UnitTestFramework folder.  See http://code.msdn.microsoft.com/silverlightut for the files.
To install the Project Linker, run the "CompositeApplicationGuidanceProjectLinker.msi" file and follow the on-screen installation steps.

===========
Please Note
===========
We are not aware of any issues with installing the Project Linker in Visual Studio, however, we have not tested all scenarios for the Project Linker
and we strongly encourage that you use a recoverable version of Visual Studio.
Alternatively, you can compile and run the Project Linker in the Visual Studio Experimental Hive, see "Running the Project Linker in the Visual Studio Experimental Hive" section.  

=========================
Project linker – Overview
=========================

The approach we are taking for multi-targeting is to provide guidance on structuring application and module code into multiple linked projects. Each project manages all of the references, resources and code specific to the WPF or Silverlight target environment.
The Project Linker is a tool that helps creating and maintaining links from a source project to a target project to share code that is common to Silverlight and WPF. Therefore shared code can be written once and built for the target environment.
Filters can be specified to avoid linking every file, this is useful if you are writing Silverlight or WPF specific code. For example you can filter out all files that have a defined prefix.

To link a source project to a target project, right click the source project and select "Add Project Link". In the window that pops up select the target project and click OK.

===============================================================================
Multi-Targeting QuickStart  –  Overview and Installation / Running Instructions
===============================================================================
The Multi-Targeting QuickStart demonstrates the structure of a project created to multi-target WPF and Silverlight environments.
The QuickStart is a real state application that shows different characteristics of properties and includes a pie chart that shows how much the property's characteristics match with the searching criteria.
This Solution consists of shared code and UI-specific code for Silverlight and WPF.

To load the Multi-Targeting QuickStart, open the "MultiTargetingQuickstart.sln" in Visual Studio.
To run the WPF version set the "RealEstateListingViewer.Net" project (located at the DotNet solution folder) as the Startup Project and press F5.
To run the Silverlight version of the QuickStart, set the "RealEstateListingViewerHost" (located at the Silverlight solution folder) project as the Startup project and press F5.

=========
Uninstall
=========
To uninstall the project linker:
• In Windows Vista, go to the control Panel and double-click the "Programs and Features" icon. Look for the "Composite Application Guidance Project Linker" item and click Uninstall.
• In Windows XP, go to the control Panel and double-click the "Add or Remove Programs" icon. Look for the "Composite Application Guidance Project Linker" item and click Remove.
• You can also uninstall the Project Linker by running the installer and selecting the "Remove the Composite Application Guidance Project Linker", to finalize click Finish.

=================================================================
Running the Project Linker in the Visual Studio Experimental Hive
=================================================================
To run the Project Linker in the Visual Studio Experimental Hive, perform the following steps.
1. Open the "ProjectLinker.sln" solution in Visual Studio.
2. Right-click the ProjectLinker project and select Properties.
3. Go to the "Debug" tab. At the "Start Actions" section, select "Start external program" and look for the Visual Studio executable file: "devenv.exe", typically located at "Program Files\Microsoft Visual Studio 9.0\Common7\IDE\".
4. At the "Start Options" section, in the "Command line arguments" textbox, enter the following arguments: "/rootsuffix Exp /RANU".
5. Save the changes.
6. Run the solution. To do this, press F5 making sure that the "ProjectLinker" project is set as the Startup Project.


Please note that some items are still under construction.