# Summary of what's new
# [New Event Aggregation QuickStart](#EventAggregationQuickStart)
# [New Elements added to Prism to support Event Aggregation](#NewElementsadded)
# [Updated the Regions implementation](#UpdatedRegionsImplementation)
{anchor:EventAggregationQuickStart}
### New Event Aggregation QuickStart
This QuickStart demonstrates how modules communicate in a decoupled way using a multicast Pub/Sub eventing mechanism. The QuickStart contains a single Window that gets populated with content from two modules, ModuleA , and ModuleB. The following figure shows the QuickStart main window. ModuleA content is added to the blue area, and ModuleB content is added to the cyan area.

![](05142008 Iteration Drop_shell.png)

The view on the left (**AddFundView**) allows the user to select a customer and add a fund for the selected customer. The views on the right, of type **ActivityView**, show the funds added for each customer. Note that there are two instances of the same view - each instance shows funds for a particular customer.

When you click **Add** on the **AddFundView** view, the view's presenter fires a typed event named **FundAddedEvent**. This event indicates that a new fund has been added to a customer. This event is handled by the corresponding **ActivityView**'s presenter, which in turn updates the view on the right to display the fund added.

Together with the event, a **FundOrder** object is supplied as a parameter. By supplying parameters, subscribers can not only get more information about the event, but also they can set filters on the parameter and have the eventing mechanism notify the subscriber only if the parameter matches the filter.

The following code shows how the **FundAddedEvent** is fired.

{{
// ModuleA\AddFundPresenter.cs
void AddFund(object sender, EventArgs e)
{
    var fundOrder = new FundOrder();
    fundOrder.CustomerID = View.Customer;
    fundOrder.TickerSymbol = View.Fund;

    _EventAggregator.Get<FundAddedEvent>().Fire(fundOrder);
} }}
| **Note**: The parameter for the **FundAddedEvent** is typed. This means that you can only pass an instance of the class **FundOrder** to the **Fire** method. |

The following code shows the subscriber code:

{{
// ModuleB\ActivityPresenter.cs
public string CustomerID
{
    get { return _customerID; }
    set
    {
        _customerID = value;
        _EventAggregator.Get<FundAddedEvent>().Subscribe(FundAddedEventHandler, ThreadOption.PublisherThread, false, fundOrder => fundOrder.CustomerID == _customerID);*

        View.Title = string.Format("Activity for: {0}", CustomerID);
    }
} }}
As you can see in the code above, a condition is set for the subscription (in this case, using a Lambda expression). This condition will be evaluated when the event is fired, and the event broker will only invoke the event handler if the condition is **true**.

The following code shows the definition of the **FundAddedEvent** event. This event extends the PrismEvent<TPayload> base class. This base class contains logic to subscribe, fire, an unsubscribe to the event.

{{
public class FundAddedEvent : PrismEvent<FundOrder>
{
} }}
In the code above, the **FundOrder** type is specified for the **PrismEvent**'s generic parameter. This type determines the type of the event's parameter.
{anchor:NewElementsadded}
## New Elements added to Prism to support Event Aggregation
* **PrismEvent**. This base class contains logic to subscribe, fire, an unsubscribe to an event. You inherit from this class in your application to define an event.
* **EventAggregator**. This class holds a list of events. Within your application, you interact with this class to obtain references to events.
* **WeakDelegate**. This class represents a delegate whose target object's lifecycle is not controlled by the delegate. To support this, weak references are used.
* **SubscriptionToken.** This class represents a token for a subscription. This token is used to facilitate the unregister process of event handlers.
{anchor:UpdatedRegionsImplementation}
### Updated the Regions implementation
* The **ItemsControlRegion** and **PanelRegion** regions were removed. Now there is a single region class named **SimpleRegion**. This region holds references to views and other content such as ViewModels or PresentationModels. These views will be associated to a particular WPF container control. This region behaves much more like a model for the recently introduced region adapters. 
* Region adapters are classes that know how to manage the content of a particular WPF control, and they bind the content of WPF container controls to the views that a **SimpleRegion** instance holds. New region adapters were introduced: **ContentControlRegionAdapter** and **ItemsControlRegionAdapter**. The **ContentControlRegionAdapter** manages **ContentControl** controls, and the **ItemsControlRegionAdapter** manages **ItemsControl** controls.
* A new class to map controls to region adapters was introduced, the **RegionAdapterMappings** class. You use this class in your application to register region adapters that will be available in your application.
* All the solutions included in the drop have been updated to use this new implementation.
* The **RegionManagerService** class was renamed to **RegionManager**.