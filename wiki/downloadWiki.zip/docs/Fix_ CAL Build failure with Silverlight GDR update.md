# Fix: CAL Build failure with Silverlight GDR update

The recent update of Silverlight from version _2.0.31005.0_ to version _2.0.40115.00 (GDR1)_ causes the **Composite.Silverlight.Tests** project to stop building successfully.

This affects the test project only, but you can still build the _Composite Application Library_ (CAL) and reference it from an application.

The reason is that there is a batch file being executed as a pre-build event that is trying to locate the Silverlight assemblies using the specific assembly version in the file path.

The batch file is called **createXap.bat** and is located at **"%sourcedir%\CAL\Silverlight\Composite.Tests\Mocks\Modules"**.

## How to fix it

**Option 1:**  The [MSDN release](http://www.microsoft.com/downloads/details.aspx?FamilyID=fa07e1ce-ca3f-4b9b-a21b-e3fa10d013dd&DisplayLang=en) has been update to correct this problem.  Download the latest source code from the download page.

**Option 2:**  Replace the batch file with the one avaliable for download below, or you can modify the following line in the script:
{{
set silverlightDll="%ProgramFiles%\Microsoft Silverlight\2.0.31005.0\mscorlib.dll"
}}
With:
{{
set silverlightDll="%ProgramFiles%\Microsoft SDKs\Silverlight\v2.0\Reference Assemblies\mscorlib.dll"
}}

This will grab the DLLs from the Silverlight SDK installation path, which is where Visual Studio looks for the assemblies when building the Silverlight projects.

Note: The file download contains this fix and also improved error checking and build output comments to better understand the flow of the script, so replacing the entire batch file is advised.

## More information
The createXap.bat file is needed because there is a test case that needs a dynamically generated XAP file stream. This batch file runs on the pre-build event of the test project and manually creates a XAP file to be included as a resource in the test assembly DLL. We are using a pre-build event because CodeDom is not available on the Silverlight CLR, so the assembly must be generated before the test cases are built and start running.
The test case that needs a XAP content resource stream is XapModuleTypeLoaderFixture.ShouldLoadDownloadedAssemblies.

## Download
Download the fixed [createXap.bat](Fix: CAL Build failure with Silverlight GDR update_createXap.bat) file and replace it in **"%sourcedir%\CAL\Silverlight\Composite.Tests\Mocks\Modules"**.