**The May 2010 release of the Composite Application Guidance with updates for Visual Studio 2010, .NET 4, Silverlight 4 and Unity 2.0 is now available [here](http://compositewpf.codeplex.com/releases/view/46046)**
The October 2009 release of the Composite Application Guidance with updates for Silverlight 3 is now available on MSDN.  Get it [here](http://www.microsoft.com/downloads/details.aspx?FamilyID=387c7a59-b217-4318-ad1b-cbc2ea453f40&displaylang=en)
The February 2009 release of the Composite Application Guidance is now available on MSDN. Get it [here](http://www.microsoft.com/downloads/details.aspx?FamilyID=fa07e1ce-ca3f-4b9b-a21b-e3fa10d013dd&DisplayLang=en)
To learn about the major changes between the June 2008 release and the February 2009 release, go [here](http://msdn.microsoft.com/en-us/library/dd490816.aspx)
To learn about known issues and fixes with the Februrary 2009 or June 2008 release, go [here](http://www.codeplex.com/CompositeWPF/Wiki/View.aspx?title=Known%20Issues%20%2f%20Fixes).

Previous releases:
[07-02-2008 June 2008 Release](07022008-Release)
[06-10-2008 Iteration Drop](06102008-Iteration-Drop)
[05-29-2008 Iteration Drop](05292008-Iteration-Drop)
[05-14-2008 Iteration Drop](05142008-Iteration-Drop)
[05-02-2008 Iteration Drop](04292008-Iteration-Drop)
[04-02-2008 Iteration Drop](04022008-Iteration-Drop)
[03-25-2008 Iteration Drop](03252008-Iteration-Drop)