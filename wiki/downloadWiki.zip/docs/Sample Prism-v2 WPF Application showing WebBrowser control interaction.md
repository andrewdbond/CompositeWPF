## Sample Prism-v2 WPF Application showing WebBrowser control interaction
The following demo application shows how to get a WebBrowser control and the sites it hosts to interact with a desktop application.

You can read more about this demo application in the following blog posts:
* [WebBrowser control Quickstart for the Composite Application Guidance for WPF and Silverlight (Prism-v2)](http://blogs.southworks.net/dschenkelman/2009/06/23/webbrowser-control-quickstart-for-the-composite-application-guidance-for-wpf-and-silverlight-prism-v2/)
* [How-to: Consume WCF services from Composite Application Guidance for WPF and Silverlight(Prism-v2) Modules](http://blogs.southworks.net/matiasb/2009/06/20/how-to-consume-wcf-services-from-composite-application-guidance-for-wpf-and-silverlightprism-v2-modules/)

You can download the file from here: [PrismWebBrowserDemo.zip](Sample Prism-v2 WPF Application showing WebBrowser control interaction_PrismWebBrowserDemo.zip).