## Composite Extensions for Windows Forms

* [Composite Extensions for Windows Forms](http://www.softinsight.com/bnoyes/2008/10/13/CompositeExtensionsForWindowsForms.aspx)
	* **Version:** 1.0
	* **Description:** A set of libraries to use the Composite Application Library in Windows Forms and a blog post describing them.