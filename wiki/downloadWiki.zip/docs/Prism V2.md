The next version of Prism is under development.  Check back on this page for the latest on release information.

We've just released the 9th drop of Prism V2, you can find the release [release:here](21912).

Blog Entries Related to Prism V2 development:

{rss:url=http://blogs.msdn.com/blaine/rss_tag_Prism.xml,max=4,titlesOnly=true}
{rss:url=http://blogs.msdn.com/dphill/rss_tag_Prism.xml,max=4,titlesOnly=true}
{rss:url=http://blogs.msdn.com/bobbrum/rss.xml,max=4,titlesOnly=true}
{rss:url=http://blogs.msdn.com/erwinvandervalk/rss.xml,max=4,titlesOnly=true}
{rss:url=http://feeds.southworks.net/sw-jdominguez,max=4,titlesOnly=true}


