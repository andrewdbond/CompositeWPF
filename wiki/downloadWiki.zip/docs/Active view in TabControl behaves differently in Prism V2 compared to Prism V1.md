If a TabControl is marked as a region with multiple views, activating a view through the region does not activate the tab containing the view.  In Prism V1, this activating a view for a TabControl region would select the tab containing the view.

**Example Code**

Given a TabControl as a region named "TabRegion"

{{
    var view1 = new TextBlock() { Text = "Tab1" };
    var view2 = new TextBlock() { Text = "Tab2" };
    var region = regionManager.Regions["TabRegion"](_TabRegion_);

    region.Add(view1);
    region.Add(view2);

    region.Activate(view2);  // Does not properly activate view2
}}

### Cause
The **SelectorItemsSourceSyncBehavior** attached to the TabControl did not update the TabControl.SelectedItem when the Regions ActiveViews collection changed.

### Fix
The [MSDN download](http://www.microsoft.com/downloads/details.aspx?FamilyID=fa07e1ce-ca3f-4b9b-a21b-e3fa10d013dd&DisplayLang=en) has been update to correct this problem.

### Disscussion and Issue
* [workitem:Go here](3889) to see the related issue.
* [discussion:Go here](48586) to see the related discussion.