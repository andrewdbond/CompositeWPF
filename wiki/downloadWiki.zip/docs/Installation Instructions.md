# Installing the Composite Application Guidance for WPF
If you want to use all the assets in the Composite Application Guidance for WPF, the following must be installed: 
* [Microsoft Visual Studio 2008.](http://msdn2.microsoft.com/en-us/vstudio/default.aspx)
* [.NET Framework 3.5.](http://www.microsoft.com/downloads/details.aspx?FamilyID=333325FD-AE52-4E35-B531-508D977D32A6&displaylang=en)
* (optional) If you want to run the acceptance tests, you need to have the White assemblies. For more information about White, including download information, see [White.](http://www.codeplex.com/white)
| **Note:** The acceptance tests have been developed and verified with the [White 0.1.5.0 release](http://www.codeplex.com/white/Release/ProjectReleases.aspx?ReleaseId=12756). Although other releases of White might work too, it is recommended to use the aforementioned release to avoid any issues when running the tests.|
## Installation Steps
Use the following steps to install the Composite Application Guidance for WPF:

| **Note:** If you are in the evaluation stage, and you only want to review the documentation you do not need to download the prerequisites or install the full package. To download the documentation, see [Documentation](http://www.codeplex.com/CompositeWPF/Release/ProjectReleases.aspx?ReleaseId=14982). |

* 1. [Download](http://www.codeplex.com/CompositeWPF/Release/ProjectReleases.aspx) and run the **Composite Application Guidance for WPF installer** 
| **Note:** The installer is just a self-extractor that copies the source files and documentation to the destination folder. |
* 2. Read and accept the Composite Application Guidance for WPF EULA. To do this select **Yes** from the Installer splash screen.
![](Installation Instructions_CWPF_EULA.PNG)
**Figure 1**
_Composite Application Guidance for WPF EULA_
* 3. Select the destination folder where you want to extract the guidance and then select **OK** to extract the files.
![](Installation Instructions_CWPF_Directory.PNG)
**Figure 2**
_Destination folder dialog_

After the extraction process completes, you will find the guidance in the folder you selected.