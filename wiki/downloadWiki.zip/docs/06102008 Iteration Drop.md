# Summary of what's new in this drop
# [Renamings](#Renamings)
# [Redistributed Assemblies](#CompositeApplicationLibraryAssemblies)
# [Refactored Regions](#RegionsRefactoring)
# [Updated Stock Trader Reference Implementation](#StockTraderRI)
# [New Spikes](#Spikes)
# [Updated Documentation](#Documentation)
## Renamings {anchor:Renamings}
* **Prism** has been renamed to **Composite Application Guidance for WPF**
* **Prism Library** has been renamed to **Composite Application Library**
## Composite Application Library Assemblies {anchor:CompositeApplicationLibraryAssemblies}
Redistributed the components into three assemblies:
* **Microsoft.Practices.Composite.dll**. This assembly contains the implementation of the Composite Application Library core components such as modularity, logging and communication services, and several core interfaces’ definitions. This assembly does not contain UI-specific elements.
* **Microsoft.Practices.Composite.Wpf.dll**. This assembly contains the implementation of Composite Application Library components that target Windows Presentation Foundation applications including commands, regions, and events.
* **Microsoft.Practices.Composite.UnityExtensions.dll**. This assembly contains the base and utility classes you can reuse in applications created with the Composite Application Library that consume the Unity Application Block. For instance, it contains a **Bootstrapper** base class —the **UnityBootstrapper** class— that creates and configures a Unity container with default services when the application starts.
## Composite Application Library - Regions refactoring {anchor:RegionsRefactoring}
 The following changes were made in the regions classes:
* The **RegionAdapterBase** base class was added. This class contains common code for region adapters. It contains logic to create regions, attach behaviors and to provide validation.
* The **Active Aware** logic was moved to a behavior class: **CollectionActiveAwareBehavior**.
* A new region adapter named **SelectorRegionAdapter** was added. This region adapter works with controls derived from **Selector**.
* New region types were added:
	* **Region**: Is the base class of the **SingleActiveRegion** and **AllActiveRegion** regions and contains their base functionality. **Activate** and **Deactivate** methods can be explicitly called.
	* **SingleActiveRegion**: Only one view is active at a time. When an item is activated, the previously activated one is automatically deactivated. **Activate** and **Deactivate** methods can be explicitly called. An example of a control that can be associated to a **SingleActiveRegion** is the **ContentControl** control.
	* **AllActiveRegion**: All views are active, for that reason, there is no need to explicitly call activate. An example of control that can be associated to an **AllActiveRegion** is the **ItemsControl** control.
## Stock Trader Reference Implementation {anchor:StockTraderRI}
The following changes were made to the Stock Trader Reference Implementation:
* Some views that had a presenter and presentation model associated, where refactored to have the logic of the presenter and presentation model classes in a single presentation model class that gets associated to the view through the **DataContext** property. See the following views for examples:
	* Position Summary view (StockTraderRI.Modules.Position\PositionSummary)
	* Order Details view (StockTraderRI.Modules.Position\Orders)
| **Note:** Simple views that did not require a **PresentationModel** were not changed. These views still use the **Supervising Controller** pattern. |
* Folders were created to group all the artifacts related to each view.
![](06102008 Iteration Drop_Folders.png)
## Spikes {anchor:Spikes}
Two new spikes were added:
* **Windsor spike**. This spike demonstrates how to use the guidance with Windsor and Log4net in Prism. Look at the following elements for details:
## **WindsorPrismContainer**. This class adapts the Windsor container to Prism.
## **WindsorPrismBootstrapper**. This class is a bootstrapper that uses Windsor.
* **FamilyShow spike**. This spike demonstrates how to integrate Prism with an existing WPF application that was not built with Prism.
| **Note:** These spikes are not intended to be used as guidance for developers. They use an old version of Prism Application Block and their main purpose is to verify that the guidance can be used with third party artifacts. |
## Documentation {anchor:Documentation}
New topics were added:
* How To: Create a View with a Presenter
* How To: Load a Module On Demand
* Region Technical concepts
* Patterns Overview
* Designer Guidance for Composite Applications for WPF