## Summary of the Problem
The Prism v2.2/v4.0 setup application invokes a Windows Scripting Host script that uses the [Shell.NameSpace](http://msdn.microsoft.com/en-us/library/bb774085(VS.85).aspx) method to open the included Sources.zip file as a folder.  The script then iterates through all the content in the archive (treated as a folder) and extracts the content. The problem occurs when a non-default shell handler is enabled for zip files that does not support a folder view of the content, for example PKZip.  The failed folder view results in an error in the script and termination without extracting the content.

## Solution
Set the windows support for Zip files as the default handler for files of the Zip type.  This can be accomplished by opening the properties for a zip file and changing the default handler.

![](Setup issues with Prism v2.2/v4.0 when a non-default program is used to open zip files_zipfile.png)

Selecting change and choosing Windows Compressed as the default handler instead of a third party handler that may not support a folder view will resolve the issue.