## Using resource dictionaries in modules

The most common issues regarding this subject are:

**If a ResourceDictionary is defined in the Shell project, this ResourceDictionary will not be available in design time in a module. (In runtime, the ResourceDictionary will be resolved correctly)**:

In this case, it would be worth noting that it’s possible to define application-wide resources out of the box, which will work in all modules. However, this doesn’t seem to work with the designer, when checking a view in a module. A possible work around would be to include the source path for the **ResourceDictionary** as a resource in the **App.xaml** file of the module doing something similar to this:

_{"<Application.Resources>"}_
    _{"<ResourceDictionary Source="/ShellProject;component/Resources/Resource.xaml"/>"}_
_{"</Application.Resources>"}_

While the **App.xaml** file in a module isn’t consumed when running the application, it is used in design-time.


**If a ResourceDictionary is defined in a module (to be used specifically inside the module), the ResourceDictionary will not be available at runtime**:

For this case, you might find the approach proposed in the following blog post by Guido Maliandi useful:
	* How to: define module-specific resource dictionaries in Prism [http://blogs.southworks.net/gmaliandi/2012/01/how-to-define-module-specific-resource-dictionaries-in-prism/](http://blogs.southworks.net/gmaliandi/2012/01/how-to-define-module-specific-resource-dictionaries-in-prism/)