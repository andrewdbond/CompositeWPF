## Tips on Posting Good Questions
* +Search for your question on the forums or in the documentation first+
	* It's likely someone may have already answered your question or a similar one and you won't have to wait for it to be answered again.
* +Make sure your title summarizes the specific problem you have+
	* Having a more specific title helps us understand your main problem and provides important information about what you want to achieve. This is really helpful when answering the question. Plus, a thread with a descriptive title is extremely useful for other users that might have a similar issue. You can find an example [here](http://compositewpf.codeplex.com/Thread/View.aspx?ThreadId=64741).
* +Give details about your problem+ 
	* Rather than "When I call new CustomersView() I get an exception, please help", provide the exception type, message, and call stack.  If possible provide a succinct code snippet that demonstrates the problem. This lets us reproduce the problem on our end, and allows us to come up with an answer where just a general question may not have had enough details.  Having this information means we can answer your question more quickly, without having to ask you for these details and wait for your response. You can find an example [here](http://smartclient.codeplex.com/Thread/View.aspx?ThreadId=207789).
* +Use the right tags+ 
	* This lets us know what version/component you are using and focus on it to reproduce your issue. It also helps other community users identify if a question will be useful for them or not, depending on the version they are using. You can find an example [here](http://compositewpf.codeplex.com/Thread/View.aspx?ThreadId=208747).
* +Post in the correct forum+ 
	* since the users of different assets tend to stick to a forum of that particular asset, a question about SCSF WorkItems posted in the Prism forum will likely take a lot longer to be answered than the same question in the SCSF forum.  
* +If you've received a correct/useful answer to your question, please add another post saying it was useful +
	* This lets people scanning the forums know that they can find a useful answer to that question by reading the thread. An example can be found [here](http://compositewpf.codeplex.com/Thread/View.aspx?ThreadId=207696).
* +Please report bugs through the issue tracker instead of on the forums+ 
	* This allows us to track the bugs easily and get them assigned to the correct person.  It also allows you to follow the problem through to its resolution, and is a much better way for us to handle issues you find than a bug report posted on the forums.  Issue tracker can be accessed [here](http://compositewpf.codeplex.com/workitem/list/basic).

