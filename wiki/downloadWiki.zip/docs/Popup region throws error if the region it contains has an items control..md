## Popup region throws error if the region it contains has an items control

### Issue
An error related to the PopupRegionBehavior, from the Silverlight StockTrader RI, occurs when:
# The Region contains a view that has an items control and
# One of the items is selected.

**Error:** {"["}System.Exception: Catastrophic failure (Exception from HRESULT: 0x8000FFFF (E_UNEXPECTED)){"](_}System.Exception_-Catastrophic-failure-(Exception-from-HRESULT_-0x8000FFFF-(E_UNEXPECTED)){_)"}.

### Cause of Issue
The childen of the popup are in the visual tree, while the popup is not. You can read more about this in the following articles:
* [Popup Class](http://msdn.microsoft.com/en-us/library/system.windows.controls.primitives.popup(VS.95).aspx) on [MSDN](http://msdn.microsoft.com/en-us/default.aspx)
* [Silverlight 2 Popup control hosting an ItemControl (ListBox, ComboBox, etc.)](http://blogs.conchango.com/darenmay/archive/2009/05/03/silverlight-2-popup-control-hosting-an-itemcontrol-listbox-combobox-etc.aspx) by [Daren May](http://blogs.conchango.com/darenmay/)

### Workaround
Add the Popup to the Visual Child before showing it. One of the ways of doing this is finding a control that inherits from panel and add the Popup to the child collection.
To apply this workaround you should modify the code of the **Show** method of the **PopupWrapper.Silverlight** class of the RI like this:
{{ 
   public static void Main()
   { 
     Panel popupContainer = GetLayoutRoot(owner);
     popupContainer.Children.Add(popUp);
     this.popUp.IsOpen = true;
   }
}}
The **GetLayoutRoot** method should return a panel object from the visual tree. Below you can find a possible implementation for it, which performs a recursive call to look for a Panel control in the Visual Tree. This could be customized according to your application needs and specifics.
{{
    private static Panel GetLayoutRoot(DependencyObject container)
        {
            for (int i = 0; i < VisualTreeHelper.GetChildrenCount(container); i++)
            {
                Panel control = VisualTreeHelper.GetChild(container, i) as Panel;
                if (control != null)
                    return control;
            }

            //recursive call
            for (int i = 0; i < VisualTreeHelper.GetChildrenCount(container); i++)
            {
                Panel control = GetLayoutRoot(VisualTreeHelper.GetChild(container, i));
                if (control != null)
                    return control;
            }

            return null;
        }
}}