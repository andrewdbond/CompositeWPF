# Migrating Prism v2.1 to Silverilght 4 RC
These are the results of the smoke tests, performed by the p&p Client Sustained Engineering team, after updating Prism v2.1 to Silverlight 4 RC version. You can download the migrated Prism bits from [here](Migrating Prism v2.1 to Silverlight 4 RC_here)(Prismv2.1SL4MIX.zip).
|**Disclaimer:** This is not a supported release. It is simply provided for demonstration purposes as to how Prism can be used with Silverlight 4 RC version.|
To run the acceptance tests, the pre-build event must be updated to (taking the RI as an example) **$(FrameworkDir)\..\v4.0.30128\msbuild.exe "$(SolutionDir)..\StockTraderRI.sln" /p:configuration=$(ConfigurationName)**.
[Image:sl4Tests.png)(Image_sl4Tests.png)