# Bootstrapper initialization is not at the Application Startup event in some of the Quickstarts and Documentation topics
## Problem
Running the Bootstrapper at the App’s constructor stage will probably let your application in an inconsistent state, for example if you try adding application resources dynamically. 
## Solution
It is recommended that the Bootstrapper initialization be placed in the handler for the **Startup** event of the Application like in the following sample code:
{{
public partial class App : Application
{
    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);

        MyBootstrapper bootstrapper = new MyBootstrapper();
        bootstrapper.Run();
    }
} }}
## Assets affected
In the first release of Composite Application Guidance, the following assets are running the Bootstrapper from the **App constructor** instead of the **Startup event** (these are **+not+** correct):
* [How to: Create a Solution Using the Composite Application Library.](http://msdn.microsoft.com/en-us/library/cc707864.aspx)
* [Composite Application Guidance for WPF Hands-On Lab](http://msdn.microsoft.com/en-us/library/cc707878.aspx) and the HelloWord QuickStart source code.
* ConfigurationModularity Quickstart source code.
* DirectoryLookupModularity Quickstart source code.
* EventAggregation Quickstart source code.
* UI Composition Quickstart source code.
## More Information
You may find information on the application’s startup in the Remarks section of these links:
* [Application.Startup Event.](http://msdn.microsoft.com/en-us/library/system.windows.application.startup(VS.85).aspx)