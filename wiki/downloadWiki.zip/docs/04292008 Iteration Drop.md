# Summary of what's new 
# [New Modularity QuickStarts](#NewModularityQuickstarts)
# [New elements in Prism to support dynamic module loading and initialization](#NewElementsInPrism)
# [New the View-Model Composition Spike](#NewViewModel)
# Added documentation for the Stock Trader Reference Implementation and UI Composition QuickStart
{anchor:NewModularityQuickstarts}
### New Modularity QuickStarts
These QuickStarts demonstrate how to perform dynamic module loading.
* **Directory LookUp Modularity QuickStart**. This QuickStart shows how to dynamically load modules using a directory lookup module enumerator. This kind of enumerator loads module assemblies from a specified folder.
* **Configuration-Based Modularity QuickStart**. This QuickStart shows how to load modules dynamically using a configuration-based module enumerator. This module enumerator determines what modules to load by reading a configuration file.
Both QuickStarts are based on the same business scenario. The only difference between them is how modules are enumerated. 

![](04292008 Iteration Drop_conceptualview.png)

**Figure 1 | QuickStarts Conceptual View**

![](04292008 Iteration Drop_modularity.png)

**Figure 2 | Modularity QuickStart UI**
{anchor:NewElementsInPrism}
### New elements in Prism to support dynamic module loading and initialization
The following list describes the main new items included in Prism to support dynamic module loading.
* **Prism\Services\DirectoryLookupModuleEnumerator.cs**. This module enumerator discovers modules in assemblies stored in a particular folder. The enumerator loads the assemblies in "reflection-only" mode (to optimize performance) and reflects over them to obtain the types that implement the IModule interface. While doing the module discovery, a separate application domain is used to encapsulate the discovery process. Note that this module enumerator supports multiple modules in a single assembly (there could be multiple classes that implement the Imodule interface).
* **Prism\Services\ConfigurationModuleEnumerator.cs**. This module enumerator discovers modules by reading the configuration file of the application. The following figure, extracted from the Configuration-Based Modularity QuickStart, illustrates a sample configuration section for modules.
{{
<modules>
    <module assemblyFile=“Modules/ModuleD.dll” moduleType=“ModuleD.ModuleO” moduleName=”ModuleD”>
        <dependencies>
            <dependency moduleName=“ModuleB”/>
        </dependencies>
    </module>
    <module assemblyFile=“Modules/ModuleB.dll” moduleType= “ModuleB.ModuleB” moduleName= “ModuleB” />
    <module assemblyFile=“Modules/ModuleA.dll” moduleType= “ModuleA.ModuleA” moduleName= “ModuleA” />
        <dependencies>
            <dependency moduleName=“ModuleD”/>
        </dependencies>
    </module>
    <module assemblyFile=”Modules/ModuleC.dll” moduleType=“ModuleC.ModuleC” moduleName= “ModuleC” allowsDelayLoading=”true”/>
</modules> }}
**Figure 3 | Modules configuration section**
* **Prism\ModuleAttribute.cs**. This attribute provides additional metadata information about a module. This attribute is read by the **DirectoryLookupModuleEnumerator** when discovering modules. The attribute contains the following properties:
	* string ModuleName. This is the name of the module.
	* string[]() DependsOn: This is a list of module names on which the module depends.
	* Bool AllowsDelayLoading: This flag indicates that the module can be loaded on demand.
* **Prism.Interfaces\IModuleEnumerator.cs**. This defines the public interface of module enumerators. The interface contains the following methods:
	* **ModuleInfo[]() GetModules()**. This method returns the metadata for all the modules discovered.
	* **ModuleInfo[]() GetNonDelayLoadedModules()**. This method returns the metadata for all modules that are not marked with the flag **AllowsDelayLoading**.
	* **ModuleInfo GetModule(string moduleName)**. This method returns the metadata for a module given its name. This method is typically used to load a module on demand.
* **Prism\Services\ModuleInitializerService.cs**. This service handles the initialization modules. It defines the modules load order, loads module assemblies, and invokes the **Initialize** method of each module class.
* **Prism.Interfaces\IModuleInitializerService**. This defines the public interface for module initializer services.
{anchor:NewViewModel}
###  New View-Model Composition Spike
In this spike a different approach to implementing views and regions is explored. 
* In this spike, views are not implemented as User controls. Instead, views are made up of a presentation Model Class and a XAML file that defines data templates for the model which are automatically injected by WPF.
| **Important**: the goal of the spike is to give visibility to the community about the research being done so that you can provide feedback. By no means this spike should be considered as a final implementation because it has not been tested and it is not ready for production. The code written in the spike might be discontinued in future releases. |