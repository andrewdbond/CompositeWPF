# Getting Started with Prism
Architects and developers will need to devote some time and effort to fully understand and evaluate Prism. Although there is no single way to evaluate a solution, this guidance divides the process into four steps:

**[Download](#Download)**. Download the guidance or documentation.
**[1. Fit analysis](#FitAnalysis)**. Determine if the guidance suits your needs. 
**[2. Initial evaluation](#InitialEvaluation)**. Install, run, and examine the guidance. 
**[3. In-depth evaluation](#InDepthEvaluation)**. Conduct a thorough examination of the guidance. 
**[4. Adoption](#Adoption)**. Incorporate the guidance into a composite application. 
**[Upgrading from earlier releases](#EarlierReleases)**. Upgrade from the Composite UI Application Block (CAB) / Smart Client Software Factory (SCSF) or Composite Client Application Guidance - June 2008 Release

The next sections describe each step. 

{anchor:Download}
## Download
Depending on your requirements and prerequisites, download one of the following versions of Prism:
* [release:Download Prism 4 CTP – August 2010](49963). This guidance is the CTP for Prism 4 and targets Visual Studio 2010, .NET Framework 4.0, and Silverlight 4 for building WPF and Silverlight applications with Unity, MEF, and/or MVVM.
* [release:Download May 2010 Guidance (version 2.2 )](46046). This guidance is the port of the 2.1 guidance to Visual Studio 2010, .NET Framework 4.0, and Silverlight 4 for building WPF and Silverlight applications.
* [Download October 2009 Guidance (version 2.1 )](http://www.microsoft.com/downloads/details.aspx?FamilyID=387c7a59-b217-4318-ad1b-cbc2ea453f40&displaylang=en). This guidance targets Visual Studio 2008, .NET Framework 3.5, and Silverlight 3 for building WPF and Silverlight applications.
* [Download June 2008 Guidance (version 1.0)](http://www.microsoft.com/downloads/details.aspx?FamilyId=6DD3D0C1-D5B4-453B-B827-98E162E1BD8D&displaylang=en). This guidance targets Visual Studio 2008 and .NET Framework 3.5 for building WPF applications (but not Silverlight).
* [release:Download documentation only in CHM format](14982)
* [Download June 2008 Documentation (version 1.0) in PDF Format](http://www.microsoft.com/downloads/details.aspx?FamilyId=E3E87BDC-FEC1-4489-91FA-E1CF69721563&displaylang=en)

{anchor:FitAnalysis}
## Step 1: Fit Analysis
Prism is for designing complex WPF or Silverlight applications. The following are scenarios where you should consider using Prism:

* You are building a composite application that presents information from multiple sources through an integrated user interface. 
* You are developing, testing, and deploying modules independently of the other modules. 
* Your application will add more views and more functionality over the coming years. 
* You must be able to change the application quickly and safely to meet emergent business requirements. 
* Your application is being developed by multiple collaborating teams. 
* Your application targets both WPF and Silverlight, and you want to share as much code as possible between the two platforms. 

Prism may not be right for you if your applications do not require one or more of these scenarios. It also may not be right for you if, for example, your application consists of a few simple screens, you are building a prototype or demonstration application, or your developers are not familiar with the ideas and practices and do not have the time to learn them.

To determine whether Prism is a potential fit, you need to understand the problems that the solution solves. The following sections may help you perform a fit analysis:

|| Topic ||Version 1.0 2008 ||Version 2.1 2009||
| **When to Use This Guidance** | [link](http://msdn.microsoft.com/en-us/library/cc707901.aspx) | [link](http://msdn.microsoft.com/en-us/library/dd490815.aspx) |
| **Goals and Benefits** |[link](http://msdn.microsoft.com/en-us/library/cc707907.aspx) | [link](http://msdn.microsoft.com/en-us/library/dd458906.aspx) |
| **Modularity design concept** | [link](http://msdn.microsoft.com/en-us/library/cc707850.aspx) | [link](http://msdn.microsoft.com/en-us/library/dd490825.aspx) |
| **UI Composition design concept** |[link](http://msdn.microsoft.com/en-us/library/cc707883.aspx) | [link](http://msdn.microsoft.com/en-us/library/dd458868.aspx) |
| **Intended Audience** | [link](http://msdn.microsoft.com/en-us/library/cc707844.aspx) | [link](http://msdn.microsoft.com/en-us/library/dd458935.aspx) |
 

This phase should take one to two hours to complete.

{anchor:InitialEvaluation}
## Step 2: Initial Evaluation
To take a closer look at Prism, you will want to learn more about the design of the Prism Library (also called the Composite Application Library) to determine how composite application architectures fit into your enterprise or solution architectures. You will also want to start looking at the code by developing a simple "Hello World" application.

The relevant topics to read for this step include the following:

|| Topic ||Version 1.0 2008 ||Version 2.1 2009||
| **Composite Application Library** | [link](http://msdn.microsoft.com/en-us/library/cc707890.aspx) | [link](http://msdn.microsoft.com/en-us/library/dd458861.aspx) |
| **Separated Presentation Pattern** | [link](http://msdn.microsoft.com/en-us/library/cc707862.aspx) | [link](http://msdn.microsoft.com/en-us/library/dd458859.aspx) |
| **Dependency Injection Pattern** | [link](http://msdn.microsoft.com/en-us/library/cc707845.aspx) | [link](http://msdn.microsoft.com/en-us/library/dd458879.aspx) |
| **Container and Services** | [link](http://msdn.microsoft.com/en-us/library/cc707875.aspx) | [link](http://msdn.microsoft.com/en-us/library/dd458913.aspx)  |
| **Event Aggregator** | [link](http://msdn.microsoft.com/en-us/library/cc707867.aspx) | [link](http://msdn.microsoft.com/en-us/library/dd458915.aspx) |
| **UI Composition** | [link](http://msdn.microsoft.com/en-us/library/cc707863.aspx) | [link](http://msdn.microsoft.com/en-us/library/dd458944.aspx) |

To get some hands-on experience, complete the following activities:

* Download and build the Prism Library
	* [October 2009](http://www.microsoft.com/downloads/details.aspx?FamilyID=387c7a59-b217-4318-ad1b-cbc2ea453f40&displaylang=en)
	* [June 2008](http://www.microsoft.com/downloads/details.aspx?FamilyId=6DD3D0C1-D5B4-453B-B827-98E162E1BD8D&displaylang=en)
* Complete the Hands-on Lab: Getting Started with the Composite Application Library
	* [2009: WPF Hands-on Lab](http://msdn.microsoft.com/en-us/library/dd458867.aspx)
	* [2009: Silverlight Hands-on Lab](http://msdn.microsoft.com/en-us/library/dd458947.aspx)
	* [June 2008: WPF Hands-on Lab](http://msdn.microsoft.com/en-us/library/cc707878.aspx)

This phase should take three to four hours to complete.

{anchor:InDepthEvaluation}
## Step 3: In-Depth Evaluation
Before deciding to use Prism for your application, you may want to perform an in-depth evaluation. The Prism team recommends you evaluate the QuickStarts and the Stock Trader Reference Implementation (Stock Trader RI) and consider developing a proof of concept application with which to gain a deep understanding of the library. At this point, you should also think about required extensions to the library and optimizations that will help you meet your organization's requirements. 

Before starting your proof-of-concept application, the Prism team recommends that you read the following:

|| Topic ||Version 1.0 2008 ||Version 2.1 2009||
| **Bootstrapper** | [link](http://msdn.microsoft.com/en-us/library/cc707847.aspx) | [link](http://msdn.microsoft.com/en-us/library/dd490820.aspx) |
| **Module** | [link](http://msdn.microsoft.com/en-us/library/cc707880.aspx) | [link](http://msdn.microsoft.com/en-us/library/dd458911.aspx) |
| **Shell and View** | [link](http://msdn.microsoft.com/en-us/library/cc707902.aspx) | [link](http://msdn.microsoft.com/en-us/library/dd490829.aspx) |
| **Commands** | [link](http://msdn.microsoft.com/en-us/library/cc707894.aspx) | [link](http://msdn.microsoft.com/en-us/library/dd458928.aspx) |
| **Communication** | [link](http://msdn.microsoft.com/en-us/library/cc707836.aspx) | [link](http://msdn.microsoft.com/en-us/library/dd458878.aspx) |
| **Multi-Targeting** | not applicable | [link](http://msdn.microsoft.com/en-us/library/dd458864.aspx) |
| **Examine the QuickStarts** | [link](http://msdn.microsoft.com/en-us/library/cc707865.aspx) | [link](http://msdn.microsoft.com/en-us/library/dd458858.aspx) |
| **Review the Reference Implementation** | [link](http://msdn.microsoft.com/en-us/library/cc707869.aspx) | [link](http://msdn.microsoft.com/en-us/library/dd458919.aspx) |

As you are developing your proof-of-concept application, you should do the following:

* Review appropriate How-to topics in the [2009 Release Development Activities](http://msdn.microsoft.com/en-us/library/dd458897.aspx) or [June 2008 Development Activities.](http://msdn.microsoft.com/en-us/library/cc707898.aspx)
* Use the [2009 Release Stock Trader RI](http://msdn.microsoft.com/en-us/library/dd458919.aspx) or the [June 2008 Stock Trader RI](http://msdn.microsoft.com/en-us/library/cc707869.aspx) to see how to implement specific tasks or features. 
* Review the deployment activities. See [Deploying WPF Applications with ClickOnce in 2009 Release,](http://msdn.microsoft.com/en-us/library/dd458921.aspx) [Deploying WPF Applications with ClickOnce in June 2008,](http://msdn.microsoft.com/en-us/library/cc707835.aspx) or [Deploying Silverlight Applications.](http://msdn.microsoft.com/en-us/library/dd458937.aspx) 
* Review the Customization Activities in [2009 Release](http://msdn.microsoft.com/en-us/library/dd458875.aspx) or [June 2008.](http://msdn.microsoft.com/en-us/library/cc707900.aspx) 

The amount of time spent on this phase will differ based on the size and nature of your proof-of-concept application. 

{anchor:Adoption}
## Step 4: Adoption
Prism has an explicit goal to provide a good adoption experience. To deliver on this goal, Prism provides the following:

* You can "opt in" and "opt out" of Prism capabilities. For example, you can consume only the services you need. 
* You can incrementally add the Prism Library capabilities to your existing WPF or Silverlight applications. 
* You can build WPF and Silverlight applications that share as much code as possible. 
* It is non-invasive because of the following:
	* It limits the Prism Library footprint in the code. 
	* It limits reliance on custom Prism attributes. You can integrate existing libraries with the Prism Library through a design that favors composition over inheritance (this avoids forcing you to inherit from the classes in the Prism Library).

To adopt Prism, you will need to perform the following tasks:
* Decide how you will use the library: as-is or customized to fit your requirements. 
* Make the key decisions described in [Key Decisions](http://msdn.microsoft.com/en-us/library/dd458860.aspx) and communicate this with the rest of your development team. 
* Educate your development team about the Prism Library. Developers should review the following:

|| Topic ||Version 1.0 2008 ||Version 2.1 2009||
| **When to Use This Guidance** | [link](http://msdn.microsoft.com/en-us/library/cc707901.aspx) | [link](http://msdn.microsoft.com/en-us/library/dd490815.aspx) |
| **Prism Assets** | [link](http://msdn.microsoft.com/en-us/library/cc707844.aspx) | [link](http://msdn.microsoft.com/en-us/library/dd490814.aspx) |
| **UI Composition technical concept** | [link](http://msdn.microsoft.com/en-us/library/cc707863.aspx) | [link](http://msdn.microsoft.com/en-us/library/dd458944.aspx) |
| **Module technical concept** | [link](http://msdn.microsoft.com/en-us/library/cc707880.aspx) | [link](http://msdn.microsoft.com/en-us/library/dd458911.aspx) |
| **Development Activities** | [link](http://msdn.microsoft.com/en-us/library/cc707898.aspx) | [link](http://msdn.microsoft.com/en-us/library/dd458897.aspx) |
| **Sample code** |[QuickStarts](http://msdn.microsoft.com/en-us/library/cc707865.aspx) and [Stock Trader RI](http://msdn.microsoft.com/en-us/library/cc707869.aspx) | [QuickStarts](http://msdn.microsoft.com/en-us/library/dd458858.aspx) and [Stock Trader RI](http://msdn.microsoft.com/en-us/library/dd458919.aspx) |

Educate your designers about working with applications using the Composite Application Library. Designers should review the following:
* [When to Use This Guidance](http://msdn.microsoft.com/en-us/library/dd490815.aspx)
* [UI Design Guidance Overview](http://msdn.microsoft.com/en-us/library/dd458938.aspx)

{anchor:EarlierReleases}
## Upgrading from Earlier Releases
If you are upgrading to Prism released in October 2009 from the previous June 2008 release, you should review [Upgrading from the Composite Application Guidance for WPF - June 2008](http://msdn.microsoft.com/en-us/library/dd490816.aspx) to understand the major differences between the two releases.

If you are upgrading from the [Composite UI Application Block](http://msdn.microsoft.com/en-us/library/cc540684.aspx) to the Composite Application Library (Prism Library), you should review [Upgrading from the Composite UI Application Block](http://msdn.microsoft.com/en-us/library/dd458940.aspx) so that you understand how the concepts in the Composite UI Application Block map to the Prism Library. 